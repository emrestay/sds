const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  const nameRegistryAddress = "0xDB4e0A5E7b0d03aA41cBB7940c5e9Bab06cc7157"; 

  const Faucet = await hre.ethers.getContractFactory("SomniaFaucet");
  const faucet = await Faucet.deploy(nameRegistryAddress);

  await faucet.waitForDeployment();

  console.log("✅ Faucet deployed to:", await faucet.getAddress());
}

main().catch(console.error);
