const { ethers } = require("hardhat");
const fs = require("fs");

const CONTRACT_ADDRESS = "0xDB4e0A5E7b0d03aA41cBB7940c5e9Bab06cc7157"; 
const ABI = [
  "event NameClaimed(string fullName, address indexed owner)"
];

async function main() {
  const provider = new ethers.JsonRpcProvider("https://dream-rpc.somnia.network");
  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);

  const fromBlock = 73236935; // deploy edilen block civarı (yaklaşık)
  const toBlock = await provider.getBlockNumber();
  const step = 1000;

  const rows = [["domain", "address"]];

  for (let i = fromBlock; i <= toBlock; i += step) {
    const end = Math.min(i + step - 1, toBlock);
    console.log(`Fetching logs from block ${i} to ${end}...`);

    const events = await contract.queryFilter("NameClaimed", i, end);

    for (const evt of events) {
      rows.push([evt.args.fullName, evt.args.owner]);
    }
  }

  const csv = rows.map(row => row.join(",")).join("\n");
  fs.writeFileSync("claims.csv", csv);

  console.log(`Export complete. ${rows.length - 1} records written to claims.csv`);
}

main().catch(console.error);
